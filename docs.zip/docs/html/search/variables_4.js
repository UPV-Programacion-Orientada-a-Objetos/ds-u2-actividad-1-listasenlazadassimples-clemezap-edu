var searchData=
[
  ['sensor_0',['sensor',['../structNodoGestion.html#ac3442dedac0e8979e53c1329ddf8f408',1,'NodoGestion']]],
  ['siguiente_1',['siguiente',['../structNodo.html#a6691e5766a27432fad708189c11f679d',1,'Nodo::siguiente'],['../structNodoGestion.html#a078cadaa4ed3d1d7beef83cf5483d866',1,'NodoGestion::siguiente']]]
];

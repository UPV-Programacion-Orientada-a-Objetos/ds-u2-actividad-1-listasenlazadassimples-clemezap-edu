var searchData=
[
  ['calcularpromedio_0',['calcularPromedio',['../classListaSensor.html#a9cd368481187ad8a4faf79db7810086b',1,'ListaSensor']]],
  ['copiarnodos_1',['copiarNodos',['../classListaSensor.html#a9756e0c2f8a12f041be26322a6ebe6ba',1,'ListaSensor']]]
];

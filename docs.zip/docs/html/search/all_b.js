var searchData=
[
  ['procesarlectura_0',['procesarlectura',['../classSensorBase.html#a7fbc0a5b444f7d16cd60ba873b8ec8e4',1,'SensorBase::procesarLectura()'],['../classSensorPresion.html#aff696aceb5e619529f911311a35d3c76',1,'SensorPresion::procesarLectura()'],['../classSensorTemperatura.html#a36227dc500c6f8be7866cb0f396894b3',1,'SensorTemperatura::procesarLectura()']]],
  ['procesartodossensores_1',['procesarTodosSensores',['../classSistemaGestion.html#a99af9790a5ea840d8810dbc63285a79b',1,'SistemaGestion']]]
];

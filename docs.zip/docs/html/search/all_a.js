var searchData=
[
  ['obtenernombre_0',['obtenerNombre',['../classSensorBase.html#adb19329ba35a359c664b66575aab7552',1,'SensorBase']]],
  ['obtenertamanio_1',['obtenerTamanio',['../classListaSensor.html#a137572f36a807fa11ee9be16eb806f66',1,'ListaSensor']]],
  ['operator_3d_2',['operator=',['../classListaSensor.html#ae70d9be0dfbc1869f34828441a908d5d',1,'ListaSensor']]]
];

var searchData=
[
  ['cabeza_0',['cabeza',['../classListaSensor.html#a7e0c7cd9a3fd891df2989fc501b0d235',1,'ListaSensor::cabeza'],['../classSistemaGestion.html#aaa8411a191d2dbf2b734da297d18c152',1,'SistemaGestion::cabeza']]]
];

var searchData=
[
  ['imprimirinfo_0',['imprimirinfo',['../classSensorBase.html#a7cf3aeb12b330c500e2a5136fa020eec',1,'SensorBase::imprimirInfo()'],['../classSensorPresion.html#ad5181690dfb24946217e882606f04428',1,'SensorPresion::imprimirInfo()'],['../classSensorTemperatura.html#a95a263967c5f9a55da09be3b11c27c86',1,'SensorTemperatura::imprimirInfo()']]],
  ['insertar_1',['insertar',['../classListaSensor.html#addc18bbdb7f6a09824a9afb7935ec0d6',1,'ListaSensor']]]
];

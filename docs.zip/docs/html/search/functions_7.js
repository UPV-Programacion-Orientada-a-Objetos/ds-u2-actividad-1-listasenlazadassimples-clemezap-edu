var searchData=
[
  ['nodo_0',['Nodo',['../structNodo.html#a96da8b61d6884126bb04fced32542df9',1,'Nodo']]],
  ['nodogestion_1',['NodoGestion',['../structNodoGestion.html#ae47a28828cdad2a36e2960253eb81b9b',1,'NodoGestion']]]
];

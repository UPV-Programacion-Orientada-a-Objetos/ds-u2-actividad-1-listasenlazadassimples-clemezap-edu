var searchData=
[
  ['cabeza_0',['cabeza',['../classListaSensor.html#a7e0c7cd9a3fd891df2989fc501b0d235',1,'ListaSensor::cabeza'],['../classSistemaGestion.html#aaa8411a191d2dbf2b734da297d18c152',1,'SistemaGestion::cabeza']]],
  ['calcularpromedio_1',['calcularPromedio',['../classListaSensor.html#a9cd368481187ad8a4faf79db7810086b',1,'ListaSensor']]],
  ['copiarnodos_2',['copiarNodos',['../classListaSensor.html#a9756e0c2f8a12f041be26322a6ebe6ba',1,'ListaSensor']]]
];

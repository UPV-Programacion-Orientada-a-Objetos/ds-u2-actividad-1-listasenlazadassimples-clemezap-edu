var searchData=
[
  ['agregarsensor_0',['agregarSensor',['../classSistemaGestion.html#a65e2c2813f0e3db74dcd71165f39717b',1,'SistemaGestion']]]
];

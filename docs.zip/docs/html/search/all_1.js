var searchData=
[
  ['buscar_0',['buscar',['../classListaSensor.html#aa9284a3cc89f6e2c46d7f2b54fb313a6',1,'ListaSensor']]],
  ['buscarsensor_1',['buscarSensor',['../classSistemaGestion.html#a486b703718e1f7db02853ffce1cecc2d',1,'SistemaGestion']]]
];

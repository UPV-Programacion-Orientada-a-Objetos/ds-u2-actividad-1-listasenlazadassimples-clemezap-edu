var searchData=
[
  ['registrarlectura_0',['registrarlectura',['../classSensorPresion.html#ac4950d8215389b85dd299872b76bc5c3',1,'SensorPresion::registrarLectura()'],['../classSensorTemperatura.html#a75a9d1899df3456b5df2b41b71551b62',1,'SensorTemperatura::registrarLectura()']]]
];

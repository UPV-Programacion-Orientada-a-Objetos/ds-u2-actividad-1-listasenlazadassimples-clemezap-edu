var searchData=
[
  ['eliminarmenor_0',['eliminarMenor',['../classListaSensor.html#a91249a76a5046cdd31c22a653e9a2573',1,'ListaSensor']]],
  ['estavacia_1',['estaVacia',['../classListaSensor.html#a2dd75ef08cf9a41dc12886b45aa0571e',1,'ListaSensor']]]
];

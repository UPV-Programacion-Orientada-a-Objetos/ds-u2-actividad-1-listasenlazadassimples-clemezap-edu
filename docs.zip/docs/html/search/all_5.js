var searchData=
[
  ['historial_0',['historial',['../classSensorPresion.html#a222d29d92733620c0f3f34928f97ce85',1,'SensorPresion::historial'],['../classSensorTemperatura.html#a655dbd17010e1fe8587d7d65705f8068',1,'SensorTemperatura::historial']]]
];

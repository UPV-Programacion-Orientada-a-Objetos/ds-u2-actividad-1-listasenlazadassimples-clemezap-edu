var searchData=
[
  ['tamanio_0',['tamanio',['../classListaSensor.html#ab3710cca68cc3d3a6c697ade52cca737',1,'ListaSensor']]]
];

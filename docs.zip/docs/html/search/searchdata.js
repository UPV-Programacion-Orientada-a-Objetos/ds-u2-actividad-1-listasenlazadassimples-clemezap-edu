var indexSectionsWithContent =
{
  0: "abcdehilmnoprst~",
  1: "lns",
  2: "lms",
  3: "abceilmnoprs~",
  4: "cdhnst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables"
};


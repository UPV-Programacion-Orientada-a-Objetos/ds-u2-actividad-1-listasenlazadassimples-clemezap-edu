var searchData=
[
  ['nombre_0',['nombre',['../classSensorBase.html#a843ba88809ed7b78942a0a4b1c484cf5',1,'SensorBase']]]
];
